var searchData=
[
  ['mit_20license',['MIT License',['../md_license.html',1,'']]]
];
