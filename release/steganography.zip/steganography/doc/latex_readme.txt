********************************************
* FIX FOR LONG TABLES IN THE GENERATED PDF *
********************************************

To fix problems with tables overlapping between pages in the generated PDF documentation, take doxygen.sty in the generated LaTeX folder:

1. First you need the longtable package. At the following line to the top of your doxygen.sty, where the other \RequirePackage commands are. This includes the package:
\RequirePackage{longtable}

2. In the doxygen.sty replace the old TabularC enviroment with a new one. What I have is to replace the <tabular> enviroment with the <longtable> enviroment.

Old version:
\newenvironment{TabularC}[1]
{
\setlength{\tmplength}
     {\linewidth/(#1)-\tabcolsep*2-\arrayrulewidth*(#1+1)/(#1)}
      \par\begin{tabular*}{\linewidth}
             
{*{#1}{|>{\PBS\raggedright\hspace{0pt}}p{\the\tmplength}}|}
}
{\end{tabular*}\par}

New version:
\newenvironment{TabularC}[1]
{
 \setlength{\tmplength}{\linewidth/(#1)-\tabcolsep*2-
\arrayrulewidth*(#1+1)/(#1)}
 \par\begin{longtable}{*{#1}{|p{\the\tmplength}}|}
}
{
 \end{longtable}\par
}

3. That's it. Run LaTeX as usual. You do not need to modify the doxygen generated LaTeX code. 

4. Don't forget to save your doxygen.sty file. You will have to rewrite it each time, because doxygen always creates a new one, but it has always the same contents. So you can modify it once and keep your copy. At this points things can be made even better e.g. with an external sty-file that is being included. I have not tested about this.

Good luck
