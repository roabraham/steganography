# Simple Image Steganography

This application provides a simple way for effective image _steganography_ designed to hide larger amount of data in an image file by replacing an entire _color component_ of the _carrier image_ instead of a few bits so you can hide much more data than a simple message. On the con, this method is much weaker than the traditional image steganorgaphy so you should choose a carrier image with a strong _dominant color palette_ and hide the data by replacing the _weakest color component_ to make this steganography less noticable. _If it is essential to hide your data properly, you should choose a different steganography tool_ as this module was designed to hide large amount of data instead of hiding data deep in the carrier image to make finding the data nearly impossible.

## Requirements

This application was designed to run on **Windows XP SP3** or later and is using [PHP Desktop](https://github.com/cztomczak/phpdesktop). To run the application on old Windows systems, you may have to install [Microsoft Visual C++ 2013 Redistributable](https://www.microsoft.com/en-us/download/details.aspx?id=40784) (`vcredist_x86.exe`).

## Usage

This is a _progressive web application_ so it can also be used as a _desktop application_. To use the application, download/checkout this entire repository, launch `steganography.exe` and follow the instructions on the screen.

## API documentation

You can find the web application's API documentation in the `doc/refman.pdf` file or the `www/doc directory`. If you launch the application, you can also find a link for the documentation on the bottom of the page. If you want to override any limitation (defined in `www/include/convert.php` file) of this application, reading the API documentation is a must. You may also have to adjust your settings in `php.ini` file.

## Multiple Licensing Information

This project consists of **multiple components**, each with its **own license**. When using this project, carefully choose based on the license of the component you intend to use:

- The **core PHP application** (located in `www/include` directory) is licensed under **MIT** (©2023 Robert Abraham).

- The **Graphical User Interface (GUI)** of the _web application_ (located in `www` directory excluding the `include` subdirectory) was built using standard [jQuery](https://jquery.com/) (located in `javascript` subdirectory) and is licensed under **MIT**.

- The **Desktop Interface** (everything in this directory excluding the `www` subdirectory) is built by [PHP Desktop](https://github.com/cztomczak/phpdesktop) and is licensed under **BSD 3-clause license**.

All licenses allow commercial use under the corresponding conditions. For more details, please refer to the `license.md` file.
